#include <stdio.h>
#include <stdlib.h>
#include<time.h>

int test[10000];

int main(int argc, char const *argv[])
{
	allocate_init();
	srand((int)time(0));
	for (int i = 0; i < 10000; i++)
	{
		int tmp = rand() % (120 - (i / 100));
		printf("%d\n", tmp);
		test[i] = allocate(tmp);
		if(i % 3 == 0)
		{
			printf("deallocate\n");
			deallocate(test[(int)(rand() % (i + 1))]);
		}
		printf("%d: %d\n", i, tmp );
	}
	return 0;
}
