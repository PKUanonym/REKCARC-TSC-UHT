#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    dialog = new Dialog(this);
    setCentralWidget(dialog);
}

MainWindow::~MainWindow()
{

}
