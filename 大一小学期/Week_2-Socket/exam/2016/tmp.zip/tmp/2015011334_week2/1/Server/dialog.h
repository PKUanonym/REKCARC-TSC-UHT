#ifndef DIALOG_H
#define DIALOG_H

#include <QtWidgets>
#include <QtNetwork>

class Dialog : public QWidget
{
    Q_OBJECT

public:
    Dialog(QWidget *parent = 0);
    ~Dialog();

protected:
    void paintEvent(QPaintEvent *event);

private slots:
    void doRead();

private:
    QUdpSocket *socket;
    QRect circle;
};

#endif // DIALOG_H
