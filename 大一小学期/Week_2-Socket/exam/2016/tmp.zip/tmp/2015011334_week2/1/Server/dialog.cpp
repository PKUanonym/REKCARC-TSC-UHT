#include "dialog.h"

Dialog::Dialog(QWidget *parent)
    : QWidget(parent)
{
    socket = new QUdpSocket(this);
    socket->bind(8706);
    connect(socket, SIGNAL(readyRead()), this, SLOT(doRead()));
}

Dialog::~Dialog()
{

}

void Dialog::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.setBrush(QBrush(Qt::yellow));
    painter.drawEllipse(circle);
}

void Dialog::doRead()
{
    QByteArray array;
    array.resize(socket->pendingDatagramSize());
    socket->readDatagram(array.data(), array.size());
    QDataStream in(array);
    in >> circle;
    qDebug() << circle;
    update();
}
