#include <QCoreApplication>
#include <QtNetwork>

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);
    QUdpSocket socket;
    int a, b, r;
    while (scanf("%d%*c %d%*c %d", &a, &b, &r) != EOF) {
        QRect tmp(a - r, b - r, r * 2, r * 2);
        QByteArray array;
        QDataStream out(&array, QIODevice::WriteOnly);
        out << tmp;
        socket.writeDatagram(array, QHostAddress::LocalHost, 8706);
    }
    return app.exec();
}
