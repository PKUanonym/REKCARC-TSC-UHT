#include "thread.h"

void Thread::run()
{
    mergesort(a, l, r);
}

void Thread::mergesort(int *a, int l, int r)
{
    if (l == r) {
        return;
    }
    int mid = (l + r) / 2;
    mergesort(a, l, mid);
    mergesort(a, mid + 1, r);
    merge(a, l, mid, mid + 1, r);
}

void Thread::merge(int *a, int l1, int r1, int l2, int r2)
{
    int tl = l1;
    int n = r2 - l1 + 1;
    int *b = new int[n];
    int tot = 0;
    for (; l1 <= r1 && l2 <= r2; ) {
        if (a[l1] < a[l2]) {
            b[tot++] = a[l1++];
        } else {
            b[tot++] = a[l2++];
        }
    }
    for (; l1 <= r1; ) {
        b[tot++] = a[l1++];
    }
    for (; l2 <= r2; ) {
        b[tot++] = a[l2++];
    }
    for (int i = 0; i < tot; ++i) {
        a[tl + i] = b[i];
    }
    delete []b;
}
