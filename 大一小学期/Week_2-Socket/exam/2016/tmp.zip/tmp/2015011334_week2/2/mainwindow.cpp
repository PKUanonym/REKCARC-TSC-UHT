#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), cnt(0), tcnt(0)
{
    QPushButton *button = new QPushButton(tr("Start"));
    setCentralWidget(button);

    QVector<int> cc;
    FILE *fin = fopen("data.txt", "r");
    int x;
    while (fscanf(fin, "%d", &x) != EOF) {
        cc.push_back(x);
    }
    n = cc.size();
    a = new int[n];
    for (int i = 0; i < n; ++i) {
        a[i] = cc[i];
    }

    int l = 0, r = n - 1;
    int mid = (l + r) / 2;
    int mid1 = (l + mid) / 2;
    int mid2 = (mid + 1 + r) / 2;

    thr1 = new Thread(a, l, mid1);
    thr2 = new Thread(a, mid1 + 1, mid);
    thr3 = new Thread(a, mid + 1, mid2);
    thr4 = new Thread(a, mid2 + 1, r);
    tt1 = new TThread(a, l, mid1, mid1 + 1, mid);
    tt2 = new TThread(a, mid + 1, mid2, mid2 + 1, r);
    tt3 = new TThread(a, l, mid, mid + 1, r);

    connect(button, SIGNAL(clicked()), this, SLOT(startSort()));
    connect(thr1, SIGNAL(finished()), this, SLOT(endSort()));
    connect(thr2, SIGNAL(finished()), this, SLOT(endSort()));
    connect(thr3, SIGNAL(finished()), this, SLOT(endSort()));
    connect(thr4, SIGNAL(finished()), this, SLOT(endSort()));
    connect(tt1, SIGNAL(finished()), this, SLOT(theEnd()));
    connect(tt2, SIGNAL(finished()), this, SLOT(theEnd()));
    connect(tt3, SIGNAL(finished()), this, SLOT(final()));
}

MainWindow::~MainWindow()
{
    delete []a;
}

void MainWindow::startSort()
{
    thr1->start();
    thr2->start();
    thr3->start();
    thr4->start();
}

void MainWindow::endSort()
{
    sender()->deleteLater();
    if (++cnt == 4) {
        qDebug() << "now here";
        tt1->start();
        tt2->start();
    }
}

void MainWindow::theEnd()
{
    sender()->deleteLater();
    if (++tcnt == 2) {
        tt3->start();
    }
}

void MainWindow::final()
{
    sender()->deleteLater();
    FILE *fout = fopen("output.txt", "w");
    for (int i = 0; i < n; ++i) {
        fprintf(fout, "%d\n", a[i]);
        if (i > 0 && a[i] < a[i - 1]) {
            qDebug() << "!!!";
        }
    }
    close();
}
