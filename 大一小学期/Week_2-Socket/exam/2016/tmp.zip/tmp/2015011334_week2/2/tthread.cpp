#include "tthread.h"

void TThread::run()
{
    merge(a, l1, r1, l2, r2);
}

void TThread::merge(int *a, int l1, int r1, int l2, int r2)
{
    int tl = l1;
    int n = r2 - l1 + 1;
    int *b = new int[n];
    int tot = 0;
    for (; l1 <= r1 && l2 <= r2; ) {
        if (a[l1] < a[l2]) {
            b[tot++] = a[l1++];
        } else {
            b[tot++] = a[l2++];
        }
    }
    for (; l1 <= r1; ) {
        b[tot++] = a[l1++];
    }
    for (; l2 <= r2; ) {
        b[tot++] = a[l2++];
    }
    for (int i = 0; i < tot; ++i) {
        a[tl + i] = b[i];
    }
    delete []b;
}
