#ifndef THREAD_H
#define THREAD_H

#include <QThread>
#include <QDebug>

class Thread : public QThread
{
public:
    Thread(int *_a, int _l, int _r) : a(_a), l(_l), r(_r) { qDebug() << _l << _r; }

protected:
    void run();

private:
    int *a, l, r;
    void mergesort(int *a, int l, int r);
    void merge(int *a, int l1, int r1, int l2, int r2);
};

#endif // THREAD_H
