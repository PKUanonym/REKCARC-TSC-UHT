#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtWidgets>
#include "thread.h"
#include "tthread.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void startSort();
    void endSort();
    void theEnd();
    void final();

private:
    int *a;
    int n;
    int cnt;
    int tcnt;
    Thread *thr1;
    Thread *thr2;
    Thread *thr3;
    Thread *thr4;
    TThread *tt1;
    TThread *tt2;
    TThread *tt3;
};

#endif // MAINWINDOW_H
