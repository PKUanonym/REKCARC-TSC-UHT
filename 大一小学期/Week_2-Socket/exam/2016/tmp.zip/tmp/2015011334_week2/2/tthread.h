#ifndef TTHREAD_H
#define TTHREAD_H

#include <QThread>

class TThread : public QThread
{
public:
    TThread(int *_a, int _l1, int _r1, int _l2, int _r2) : a(_a), l1(_l1), r1(_r1), l2(_l2), r2(_r2) {}

protected:
    void run();

private:
    int *a, l1, r1, l2, r2;
    void merge(int *a, int l1, int r1, int l2, int r2);
};

#endif // TTHREAD_H
