#ifndef SOCKET_H
#define SOCKET_H

#include <QtNetwork>

class Socket : public QTcpSocket
{
    Q_OBJECT

public:
    Socket(QObject *parent = 0);
    ~Socket();

private slots:
    void doRead();

private:
    QFile file;
    int id;
    int size;
    int totalSize;
    int value;
    quint16 nextBlockSize;
};

#endif // SOCKET_H
