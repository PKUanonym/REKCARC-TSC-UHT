#include "socket.h"

Socket::Socket(QObject *parent) :
    QTcpSocket(parent)
{
    connect(this, SIGNAL(readyRead()), this, SLOT(doRead()));
    connect(this, SIGNAL(disconnected()), this, SLOT(deleteLater()));

    nextBlockSize = 0;
}

Socket::~Socket()
{

}

void Socket::doRead()
{
    QString text = readAll();
    qDebug() << text;
    if (!(text[0] == 'G' && text[1] == 'E' && text[2] == 'T')) {
        return;
    }
    QString filename = "";
    for (int i = 5; text[i] != ' '; ++i) {
        filename += text[i];
    }
    qDebug() << filename;
    QFile file(filename);
    file.open(QIODevice::ReadOnly);
    QString cont = file.readAll();
    QString res = QString("HTTP/1.1 200 OK\nContent-Type: text/html;charset=utf-8\nContent-Length: %1\n\n%2").arg(cont.size()).arg(cont);
    qDebug() << res;
    write(res.toStdString().c_str());
}
