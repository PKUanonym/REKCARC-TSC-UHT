#include "server.h"

Server::Server(QObject *parent) :
    QTcpServer(parent)
{

}

Server::~Server()
{
    emit willBeDestroyed();
}

void Server::incomingConnection(qintptr handle)
{
    qDebug() << handle;
    QThread *thread = new QThread(this);
    Socket *socket = new Socket;
    socket->setSocketDescriptor(handle);
    socket->moveToThread(thread);
    connect(socket, SIGNAL(disconnected()), thread, SLOT(quit()));
    connect(this, SIGNAL(willBeDestroyed()), thread, SLOT(quit()));
    connect(this, SIGNAL(willBeDestroyed()), socket, SLOT(deleteLater()));
    connect(thread, SIGNAL(finished()), thread, SLOT(deleteLater()));
    thread->start();
}
