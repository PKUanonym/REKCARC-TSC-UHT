#ifndef SERVER_H
#define SERVER_H

#include "socket.h"

class Server : public QTcpServer
{
    Q_OBJECT

public:
    Server(QObject *parent = 0);
    ~Server();

signals:
    void willBeDestroyed();

protected:
    void incomingConnection(qintptr handle);
};

#endif // SERVER_H
