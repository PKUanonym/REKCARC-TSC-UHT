#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    srand(time(0));
    ui->setupUi(this);
    server = new Server(this);
    server->listen(QHostAddress("127.0.0.1"), 8888);
    qDebug() << "TT";
}

Dialog::~Dialog()
{
    delete ui;
}

/*void Dialog::on_pushButton_clicked()
{
    for (int i = 0; i < 5; ++i) {
        if (isAvailable[i]) {
            isAvailable[i] = false;
            label[i]->setText(ui->lineEdit->text());
            ui->lineEdit->clear();
            QByteArray array;
            QDataStream out(&array, QIODevice::WriteOnly);
            out << QHostAddress("127.0.0.1") << port << i << label[i]->text();
            udpSocket->writeDatagram(array, QHostAddress("127.0.0.1"), 4000);
            return;
        }
    }
    QMessageBox::information(this, "提示", "已经有5个下载任务");
}

void Dialog::setAvailable(int id)
{
    isAvailable[id] = true;
    label[id]->setText("");
    bar[id]->setValue(0);
}

void Dialog::updateBar(int id, int value)
{
    qDebug() << "updateBar" << id << value << bar[id]->maximum();
    bar[id]->setValue(value);
    if (bar[id]->value() == bar[id]->maximum()) {
        QMessageBox::information(this, "提示", QString("%1下载完成").arg(label[id]->text()));
        setAvailable(id);
    }
}*/
