#include "dayedit.h"

dayedit::dayedit()
{

}

dayedit::~dayedit()
{

}

