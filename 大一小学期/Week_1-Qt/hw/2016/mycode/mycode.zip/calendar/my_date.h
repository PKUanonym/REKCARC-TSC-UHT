#ifndef MY_DATE_H
#define MY_DATE_H


class my_date : public QDate
{
public:
    my_date();
    ~my_date();
};

#endif // MY_DATE_H
