#include "my_date.h"

my_date::my_date()
{

}

my_date::~my_date()
{

}

