#ifndef DAYEDIT_H
#define DAYEDIT_H
#include <QDialog>

class dayedit : public QDialog
{
public:
    dayedit();
    ~dayedit();
};

#endif // DAYEDIT_H
