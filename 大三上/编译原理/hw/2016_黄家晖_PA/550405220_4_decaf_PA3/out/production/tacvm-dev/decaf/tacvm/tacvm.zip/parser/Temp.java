package decaf.tacvm.parser;

public class Temp {
	public String name;

	public int iVal;

	public boolean isConst;
}
