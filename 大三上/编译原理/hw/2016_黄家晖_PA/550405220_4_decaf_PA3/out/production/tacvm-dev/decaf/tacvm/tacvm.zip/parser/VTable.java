package decaf.tacvm.parser;

import java.util.List;

public class VTable {
	
	public String name;
	
	public String className;
	
	public String parentName;
	
	public List<Entry> entrys;
	
	public int offset;

}
