/*
#include <iostream>
#include <string>
//#include <bits/stdc++.h>
#include "Fraction.h"
#include "calculate.h"
*/