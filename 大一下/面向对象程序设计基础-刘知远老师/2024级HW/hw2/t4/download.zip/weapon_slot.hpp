#pragma once
#include "weapon.hpp"

class WeaponSlot {
};