#include "Test.h"
#include <iostream>
using namespace std;

Test f1(Test a){
    a.print("a");
    return a;
}
Test& f2(Test& b){
    b.print("b");
    return b;
}
void f3(Test& a, Test& b){
    Test c = std::move(a);
    a = std::move(b);
    b = std::move(c);
}