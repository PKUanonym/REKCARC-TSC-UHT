#pragma once

#include "AbstractFactory.h"

class HumanFactory: public AbstractFactory
{
public:
    //TODO
};

class OrcFactory : public AbstractFactory {
public: 
    //TODO
};
