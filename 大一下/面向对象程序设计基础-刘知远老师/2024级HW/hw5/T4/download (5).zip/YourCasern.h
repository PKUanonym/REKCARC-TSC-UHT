#pragma once

#include "Footman.h"
#include "Commander.h"
#include "Belong.h"
#include "Casern.h"

class HumanFootman :  public Footman {
public:
    //TODO
};

class OrcFootman :  public Footman {
public:
    //TODO
};

class HumanCommander :  public Commander {
public:
    //TODO
};

class OrcCommander :  public Commander {
public:
    //TODO
};

class HumanBelong :  public Belong {
public:
    //TODO
};

class OrcBelong :  public Belong {
public:
    //TODO
};

class HumanCasern : public Casern {
public:
    //TODO
};

class OrcCasern : public Casern {
public:
	//TODO
};
