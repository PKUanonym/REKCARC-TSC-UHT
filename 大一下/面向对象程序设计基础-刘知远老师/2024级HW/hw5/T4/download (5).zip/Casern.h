#pragma once
#include "Footman.h"
#include "Commander.h"
#include "Belong.h"
#include <vector>


class Casern {
    //TODO
public:
    virtual std::string getKind() = 0;
	//TODO
};