//
//  main.cpp
//  mediator
//
//  Created by 赖金霖 on 17/5/26.
//  Copyright © 2017年 赖金霖. All rights reserved.
//

#include "Mediator.h"
#include "User.h"
#include "VIPUser.h"
#include "RegularUser.h"
#include "GuestUser.h"

int main(int argc, const char * argv[]) {
	VIPUser* Dalao=new VIPUser("Dalao");
	VIPUser* Julao=new VIPUser("Julao");
	RegularUser* Xuezhang=new RegularUser("Xuezhang");
	RegularUser* Xuejie=new RegularUser("Xuejie");
	GuestUser* Mengxin=new GuestUser("Mengxin");
	GuestUser* Xuezha=new GuestUser("Xuezha");
	Mediator* Medium=new Mediator;
	Medium->AddUser(Dalao);
	Medium->AddUser(Julao);
	Medium->AddUser(Xuezhang);
	Medium->AddUser(Xuejie);
	Medium->AddUser(Mengxin);
	Medium->AddUser(Xuezha);
	
	Dalao->GreetVIP();
	Xuezhang->GreetVIP();
	Mengxin->GreetRegular();
	Xuezha->GreetGuest();
	Medium->GreetGuest(NULL);
	return 0;
}
