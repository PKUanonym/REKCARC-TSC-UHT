//
//  Mediator.cpp
//  mediator
//
//  Created by 赖金霖 on 17/5/26.
//  Copyright © 2017年 赖金霖. All rights reserved.
//

#include "Mediator.h"

Mediator::Mediator(){
	UserList.clear();
}

void Mediator::GreetVIP(User* Moer){
	for(std::vector<User*>::iterator i=UserList.begin();i!=UserList.end();++i)
		if((*i)->Type()=="VIP")(*i)->Mo(Moer);
}

void Mediator::GreetRegular(User* Moer){
	for(std::vector<User*>::iterator i=UserList.begin();i!=UserList.end();++i)
		if((*i)->Type()=="Regular")(*i)->Mo(Moer);
}

void Mediator::GreetGuest(User* Moer){
	for(std::vector<User*>::iterator i=UserList.begin();i!=UserList.end();++i)
		if((*i)->Type()=="Guest")(*i)->Mo(Moer);
}

void Mediator::AddUser(User* NewUser){
	UserList.push_back(NewUser);
	NewUser->Medium=this;
}
