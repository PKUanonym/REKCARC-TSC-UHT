//
//  Mediator.h
//  mediator
//
//  Created by 赖金霖 on 17/5/26.
//  Copyright © 2017年 赖金霖. All rights reserved.
//

#ifndef Mediator_h
#define Mediator_h

#include <vector>
#include "User.h"

class mediator{
public:
	virtual void GreetVIP(User*)=0;
	virtual void GreetRegular(User*)=0;
	virtual void GreetGuest(User*)=0;
	virtual void AddUser(User*)=0;
};

class Mediator: public mediator{
private:
	std::vector<User*> UserList;
public:
	void GreetVIP(User*);
	void GreetRegular(User*);
	void GreetGuest(User*);
	void AddUser(User*);
	Mediator();
};

#endif /* Mediator_h */
