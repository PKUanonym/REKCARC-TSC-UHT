//
//  RegularUser.h
//  mediator
//
//  Created by 赖金霖 on 17/5/26.
//  Copyright © 2017年 赖金霖. All rights reserved.
//

#ifndef RegularUser_h
#define RegularUser_h

#include "User.h"
#include "Mediator.h"

class RegularUser: public User{
public:
	void GreetVIP(){
		if(Medium)Medium->GreetVIP(this);
	}
	void GreetRegular(){
		if(Medium)Medium->GreetRegular(this);
	}
	void GreetGuest(){}
	virtual std::string Type(){
		return "Regular";
	}
	RegularUser(std::string T):User(T){}
	RegularUser();
	virtual ~RegularUser(){};
};

#endif /* RegularUser_h */
