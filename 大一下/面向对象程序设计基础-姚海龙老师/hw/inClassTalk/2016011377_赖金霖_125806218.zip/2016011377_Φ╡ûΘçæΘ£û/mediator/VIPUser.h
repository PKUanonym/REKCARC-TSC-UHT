//
//  VIPUser.h
//  mediator
//
//  Created by 赖金霖 on 17/5/26.
//  Copyright © 2017年 赖金霖. All rights reserved.
//

#ifndef VIPUser_h
#define VIPUser_h

#include "User.h"
#include "Mediator.h"

class VIPUser: public User{
public:
	void GreetVIP(){
		if(Medium)Medium->GreetVIP(this);
	}
	virtual void GreetRegular(){}
	virtual void GreetGuest(){}
	virtual std::string Type(){
		return "VIP";
	}
	VIPUser(std::string T):User(T){}
	VIPUser();
	virtual ~VIPUser(){};
};

#endif /* VIPUser_h */
