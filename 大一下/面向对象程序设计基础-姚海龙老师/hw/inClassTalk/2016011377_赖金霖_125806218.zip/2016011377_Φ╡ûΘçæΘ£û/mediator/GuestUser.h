//
//  GuestUser.h
//  mediator
//
//  Created by 赖金霖 on 17/5/26.
//  Copyright © 2017年 赖金霖. All rights reserved.
//

#ifndef GuestUser_h
#define GuestUser_h

#include "User.h"
#include "Mediator.h"

class GuestUser: public User{
public:
	void GreetVIP(){
		if(Medium)Medium->GreetVIP(this);
	}
	void GreetRegular(){
		if(Medium)Medium->GreetRegular(this);
	}
	void GreetGuest(){
		if(Medium)Medium->GreetGuest(this);
	}
	virtual std::string Type(){
		return "Guest";
	}
	GuestUser(std::string T):User(T){}
	GuestUser();
	virtual ~GuestUser(){};
};

#endif /* GuestUser_h */
