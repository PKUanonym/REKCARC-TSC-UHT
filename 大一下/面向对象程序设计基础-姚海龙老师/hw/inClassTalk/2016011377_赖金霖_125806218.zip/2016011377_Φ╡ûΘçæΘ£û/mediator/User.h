//
//  User.h
//  mediator
//
//  Created by 赖金霖 on 17/5/26.
//  Copyright © 2017年 赖金霖. All rights reserved.
//

#ifndef User_h
#define User_h

#include <string>
#include <cstdio>
#include "Mediator.h"

class Mediator;

class User{
private:
	std::string name;
protected:
	Mediator* Medium;
	void Mo(User* Moer){
		if(Moer==NULL)printf("Mo %s! \n",name.c_str());
		else if(this!=Moer)printf("%s: Mo %s! \n",Moer->GetName().c_str(),name.c_str());
	}
public:
	friend class Mediator;
	virtual void GreetVIP()=0;
	virtual void GreetRegular()=0;
	virtual void GreetGuest()=0;
	virtual std::string Type()=0;
	std::string& GetName(){
		return name;
	}
	User(std::string T){
		name=T;
		Medium=NULL;
	}
	User();
	virtual ~User(){};
};

#endif /* User_h */
