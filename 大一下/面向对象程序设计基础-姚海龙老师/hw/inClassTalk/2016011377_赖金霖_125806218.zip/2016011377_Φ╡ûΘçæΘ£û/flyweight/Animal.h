//
//  Animal.h
//  flyweight
//
//  Created by 赖金霖 on 17/5/27.
//  Copyright © 2017年 赖金霖. All rights reserved.
//

#ifndef Animal_h
#define Animal_h

#include <string>
#include <cstdio>

class Animal{
private:
	std::string Name;
public:
	std::string GetName(){
		return Name;
	}
	Animal(std::string NAME){
		Name=NAME;
	}
	Animal();
	void MakeNoise(){
		if(Name=="cat")printf("Miao Miao Miao, Nyan Nyan Nyan\n");
		else if(Name=="dog")printf("Wo Wo Won\n");
		else if(Name=="frog")printf("Naive!\n");
		else printf("Um Um Um\n");
	}
};

#endif /* Animal_h */
