//
//  FlyWeight.h
//  flyweight
//
//  Created by 赖金霖 on 17/5/26.
//  Copyright © 2017年 赖金霖. All rights reserved.
//

#ifndef FlyWeight_h
#define FlyWeight_h

#include "Animal.h"
#include <vector>
#include <string>

class FlyWeight{
private:
	std::vector<Animal*> AnimalList;
public:
	Animal* Find(std::string);
	void Add(Animal*);
	~FlyWeight();
};

#endif /* FlyWeight_h */
