//
//  main.cpp
//  flyweight
//
//  Created by 赖金霖 on 17/5/26.
//  Copyright © 2017年 赖金霖. All rights reserved.
//

#include <iostream>
#include <string>
#include "FlyWeight.h"
#include "Animal.h"

int main(int argc, const char * argv[]) {
	FlyWeight* Server=new FlyWeight;
	while(1){
		std::cout<<"Server, give me a ";
		std::string Name;
		std::cin>>Name;
		Animal* A=Server->Find(Name);
		A->MakeNoise();
	}
	return 0;
}
