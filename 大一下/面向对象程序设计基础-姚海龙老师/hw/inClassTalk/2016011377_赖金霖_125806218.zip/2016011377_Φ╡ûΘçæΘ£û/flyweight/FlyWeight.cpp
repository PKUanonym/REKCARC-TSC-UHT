//
//  FlyWeight.cpp
//  flyweight
//
//  Created by 赖金霖 on 17/5/26.
//  Copyright © 2017年 赖金霖. All rights reserved.
//

#include "FlyWeight.h"

Animal* FlyWeight::Find(std::string Name){
	for(std::vector<Animal*>::iterator i=AnimalList.begin();i!=AnimalList.end();++i)
		if((*i)->GetName()==Name)return *i;
	Animal* NEW=new Animal(Name);
	AnimalList.push_back(NEW);
	return NEW;
}

void FlyWeight::Add(Animal* A){
	if(Find(A->GetName()))return;
	AnimalList.push_back(A);
}

FlyWeight::~FlyWeight(){
	for(std::vector<Animal*>::iterator i=AnimalList.begin();i!=AnimalList.end();++i)
		delete *i;
}
