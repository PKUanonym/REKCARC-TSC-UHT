//
//  Array.h
//  iterator
//
//  Created by 赖金霖 on 17/5/26.
//  Copyright © 2017年 赖金霖. All rights reserved.
//

#ifndef Array_h
#define Array_h

#include "Iterator.h"

template<class T>
class Array{
private:
	T* Arr;
	int Num;
public:
	Array(int N){
		Num=N;
		Arr=new T[N+1];
	}
	Array();
	
	T& operator [](int p){
		return Arr[p];
	}
	
	T* begin(){
		return Arr;
	}
	T* end(){
		return Arr+Num;
	}
	
	class iterator;
};

#include "ArrayIterator.h"

#endif /* Array_h */
