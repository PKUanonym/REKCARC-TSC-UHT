//
//  main.cpp
//  iterator
//
//  Created by 赖金霖 on 17/5/25.
//  Copyright © 2017年 赖金霖. All rights reserved.
//

#include <iostream>
#include "Array.h"

int main(int argc, const char * argv[]) {
	Array<int> A(10);
	for(int i=0;i<10;i++)
		A[i]=i;
	for(Array<int>::iterator i=A.begin();i!=A.end();++i){
		printf("%d\n",**i);
	}
	return 0;
}
