//
//  ArrayIterator.h
//  iterator
//
//  Created by 赖金霖 on 17/5/26.
//  Copyright © 2017年 赖金霖. All rights reserved.
//

#ifndef ArrayIterator_h
#define ArrayIterator_h

template<class T>
class Array<T>::iterator:public Iterator<T>{
private:
	T* Place;
public:
	iterator(T* Pointer){
		*this=Pointer;
	}
	iterator& operator ++(){
		Place++;
		return *this;
	}
	iterator& operator ++(int){
		iterator* Ret=new iterator(Place);
		Place++;
		return *Ret;
	}
	iterator& operator =(T* Pointer){
		Place=Pointer;
		return *this;
	}
	bool operator ==(T* Pointer){
		if(Place==Pointer)return true;
		return false;
	}
	bool operator !=(T* Pointer){
		return !(*this==Pointer);
	}
	T* operator *(){
		return Place;
	}
};

#endif /* ArrayIterator_h */
