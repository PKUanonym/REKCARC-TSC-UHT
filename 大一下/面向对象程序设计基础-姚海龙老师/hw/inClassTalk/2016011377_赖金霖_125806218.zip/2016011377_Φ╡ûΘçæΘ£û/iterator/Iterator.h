//
//  Iterator.h
//  iterator
//
//  Created by 赖金霖 on 17/5/26.
//  Copyright © 2017年 赖金霖. All rights reserved.
//

#ifndef Iterator_h
#define Iterator_h

template<class T>
class Iterator{
public:
	virtual Iterator& operator ++()=0;
	virtual Iterator& operator ++(int)=0;
	virtual Iterator& operator =(T*)=0;
	virtual bool operator ==(T*)=0;
	virtual bool operator !=(T*)=0;
	virtual T* operator *()=0;
};

#endif /* Iterator_h */
