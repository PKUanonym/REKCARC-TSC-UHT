#include <iostream>
#include <string>
#include <vector>
#include <boost/regex.hpp>

using namespace std;
using boost::regex;
using boost::regex_match;

int main()
{
    regex IPv4Format("^((?:(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d)))\\.){3}(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d))))$");

    vector<string> vec;
    vec.push_back(string("192.168.0.1"));
    vec.push_back(string("255.255.255.255"));
    vec.push_back(string("100.300.1.999"));
    vec.push_back(string("45.32.19.64"));
    vec.push_back(string("123.234.000.001"));

    for (auto s : vec)
        cout << s << "\t" << (regex_match(s, IPv4Format) ? "ok" : "invalid") << "\n";
    return 0;
}
