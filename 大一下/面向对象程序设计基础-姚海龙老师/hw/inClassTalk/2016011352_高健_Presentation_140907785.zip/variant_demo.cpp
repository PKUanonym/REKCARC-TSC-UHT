#include <iostream>
#include <string>
#include <cassert>
#include <boost/variant.hpp>

using namespace std;
using boost::variant;

int main()
{
    variant<double, int, string> dis;

    assert(dis.type() == typeid(double));
    cout << dis << endl;

    dis = 5;

    assert(dis.type() == typeid(int));
    cout << dis << endl;

    dis = "DEMO STRING";

    assert(dis.type() == typeid(string));
    cout << dis << endl;

    return 0;
}
