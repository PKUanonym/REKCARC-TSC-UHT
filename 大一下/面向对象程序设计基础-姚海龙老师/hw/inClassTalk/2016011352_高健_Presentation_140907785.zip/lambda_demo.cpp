#include <iostream>
#include <string>
#include <algorithm>
#include <functional>
#include <boost/lambda/lambda.hpp>

using namespace std;
using namespace boost::lambda;

int main()
{
    //Boost style
    int a[] = {1, 3, 2, 4, 5};

    for_each(a, a + 5, cout << _1 << " ");
    cout << endl;

    /** It's also possible to store a boost-style lambda function
     ** in a [function] variant (C++11 <functional>, or <boost/function.hpp>).
     ** However, function pointers are not available.
     **/

    function<void(string, string, string)> f = cout << _1 << " " << _3 << _2 << "\n";
    f("Hello", "!", "World");

    //C++11 style
    [](string p, string q, string r){cout << p << " " << r << q << "\n";} ("Hello", "!", "World");

    return 0;
}
