For those who want to compile/run my code:

    These source codes cannot be simply compiled under Code::blocks environment.
    Please refer to tutorials(with the help of Google or Baidu), create a project for each code file and configure the environment variable properly. Of course you need to install Boost first.
    Notice that for regex.cpp, you would also have to link some certain .a file to avoid 'undefined reference' compile error. Configure that in Build Options->Linker Settings. About the .a files, you may search for 'libboost_regex-mgw49-mt-1_63.a' in your installation directory.

Sincerely,
Jian Gao

Mar 14, White Valentine's Day, 2017